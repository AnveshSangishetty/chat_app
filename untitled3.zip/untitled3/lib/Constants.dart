class Constants {
  static String myphn='.';
  static String myname='.';
  static List <String> months=['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
}